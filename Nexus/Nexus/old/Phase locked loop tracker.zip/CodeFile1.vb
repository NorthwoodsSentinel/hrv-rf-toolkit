﻿Module ProcessingCode

    Public Function ProcessData(ByRef SourceFile As String) As Array

        SampleCount = GetSampleCount(SourceFile)

        If LAST_SAMPLE = 0 Or LAST_SAMPLE > SampleCount Then LAST_SAMPLE = SampleCount

        Console.WriteLine()
        Console.WriteLine("   File Sample Count: {0,6}", SampleCount)
        Console.WriteLine("Total Recording Secs: {0,6}", SampleCount / 256)
        Console.WriteLine("                Mins: {0,6}", SampleCount / 256 / 60)
        Console.WriteLine()

        Dim SampleSet(SampleCount, TRACE_COUNT) As Double

        GetSampleSet(SourceFile, SampleSet, 0)

		FilterBreathData(SampleSet)	' A 20Hz high-pass filter to remove DC bias from the breathing data

        Process_Raw_EKG(SampleSet)
        RemoveEctopicBeats(SampleSet)

        'RwaveCount = AddBeatInterlinkLines(SampleSet)
        RwaveCount = GetRwaveCount(SampleSet)
        'Console.WriteLine("R Wave Count = " & RwaveCount)

        Array.Resize(RwaveTime, RwaveCount)
        Array.Resize(RwaveVal, RwaveCount)
        Array.Resize(RwaveVals, RwaveCount)
        Array.Resize(RmsVal, RwaveCount)

        BuildRwaveArrays(SampleSet)
        WriteRtoRintervalFile(SourceFile, RwaveCount)
        'WriteHeartWaveFile(SourceFile, RwaveCount)

        'BuildRmsTimeline()

        'AverageAndInvertRwave()
        RebaseAndInvertRwaves()
		FindHrvPeaks()

		'WriteSmoothHeartFile(SourceFile, SampleSet)

        MeasurePeakToPeak()
		RescaleBR(SampleSet)
		RescaleHR()
		ProcessBreathData(SampleSet)
		PhaseLockBreathing(SampleSet)
		'TrackBreathingRate(SampleSet)

		FileProcessed = True

        Return SampleSet

        'DropTarget.Display(SampleSet)

    End Function
	'Sub WriteSmoothHeartFile(ByVal SourceFile As String, ByRef SampleSet As Array)

	'AveragingWindowSmoother(SampleSet, 4, 2, 11)

	'Dim RRintervalFile = Replace(SourceFile, ".txt", "-wave.dat")
	'Dim file = My.Computer.FileSystem.OpenTextFileWriter(RRintervalFile, False, System.Text.Encoding.ASCII)
	'For n = 0 To LAST_SAMPLE
	'file.WriteLine(SampleSet(n, 4))
	'Next
	'file.Close()

	'End Sub
    Function GetSampleCount(ByRef SourceFile As String) As Integer

        Dim InData = False, SampleCount = 0

        If InStr(SourceFile, ".dat") Then
            InData = True
        End If

        Using LineIn As New FileIO.TextFieldParser(SourceFile)
            LineIn.TextFieldType = FileIO.FieldType.Delimited
            LineIn.SetDelimiters(",", vbTab)
            While Not LineIn.EndOfData
                If InData Then
                    Try
                        Dim DatumCount = LineIn.ReadFields().Length
                        If DatumCount >= 2 And DatumCount <= 4 Then SampleCount = SampleCount + 1
                    Catch
                    End Try
                Else
                    If String.Compare(Left(LineIn.ReadLine, 6), "Sensor") = 0 Then InData = True
                End If
            End While
        End Using

        Return SampleCount

    End Function
    Sub GetSampleSet(ByRef SourceFile As String, ByRef TheSampleSet As Array, ByVal HRSlot As Integer)

        Dim InData = False, SampleNumber = 0

        If InStr(SourceFile, ".dat") Then
            InData = True
        End If

        Using LineIn As New FileIO.TextFieldParser(SourceFile)
            LineIn.TextFieldType = FileIO.FieldType.Delimited
            LineIn.SetDelimiters(",", vbTab)
            While Not LineIn.EndOfData
                If InData Then
                    Try
                        Dim Datums = LineIn.ReadFields()
                        If Datums.Length >= 2 And Datums.Length <= 4 Then
                            TheSampleSet(SampleNumber, HRSlot) = Datums(0)
                            TheSampleSet(SampleNumber, 1) = Datums(1)
                            If (HRSlot = 2) Then
                                TheSampleSet(SampleNumber, 0) = Datums(2)
                            End If
                            SampleNumber = SampleNumber + 1
                        End If
                    Catch
                    End Try
                Else
                    If String.Compare(Left(LineIn.ReadLine, 6), "Sensor") = 0 Then InData = True
                End If
            End While
        End Using

    End Sub
    Sub FilterBreathData(ByRef SampleSet As Array)
		' This is a high-pass filter with a very low corner frequency of 0.05Hz
		' (20 second response time). It is used to AC-couple the breathing to
		' normalize and bring it down to a zero centerline. It is designed to
		' introduce negligible phase shift into the breath data.
        '
        ' https://www-users.cs.york.ac.uk/~fisher/mkfilter/trad.html
        ' 
        ' Chebyshev - Highpass - 256 samples/sec - (-1 dB ripple) Corner Freq 0.05Hz

        Dim xv0, xv1, yv0, yv1 As Double

        xv1 = SampleSet(0, 1)

        For n = 0 To LAST_SAMPLE
			xv0 = xv1
			xv1 = SampleSet(n, 1) / 1.000312225
			yv0 = yv1
			yv1 = xv1 - xv0 + 0.9993757454 * yv0
			SampleSet(n, 1) = yv1
		Next
	End Sub
    Sub Process_Raw_EKG(ByRef SampleSet As Array)
        ' This takes in the raw EKG and returns an Array of inter-beat intervals

        ' 0: Raw HR Source Data
        ' 2: dv/dt encoded HR
        ' 3: ROI (region of interest) data
        ' 4: R-Wave Point

        ' INPUT: 0 / OUTPUT: 1

        'LogSamples(SampleSet, 0)

        Dim t0, t1, t2 As Double
        '
        ' This is a weighted dv/dt differentiator functioning as a history-weighted high-pass
        ' filter to move the EKG's DC component and preferentially feature-extract the R-Wave 
        ' 
        t0 = t1 = t2 = SampleSet(0, 0)
        For n = 3 To LAST_SAMPLE
            SampleSet(n - 3, 2) = (t0 * 1.0 + t1 * 0.5 + t2 * 0.25) / 1.75 - SampleSet(n, 0)
            t0 = t1
            t1 = t2
            t2 = SampleSet(n, 0)
        Next
        '
        ' This performs a 5-point center-average to ignore noise and determine
        ' ROI's (regions of interest) which we then use to detect R-wave maxima
        '
        For n = 2 To LAST_SAMPLE - 2
            SampleSet(n, 3) = (SampleSet(n - 2, 2) + SampleSet(n - 1, 2) + SampleSet(n, 2) + SampleSet(n + 1, 2) + SampleSet(n + 2, 2)) / 5
        Next

        ' seven-point centered average
        'For n = 3 To SampleSet.GetUpperBound(0) - 3
        'SampleSet(n, 3) = (SampleSet(n - 3, 2) + SampleSet(n - 2, 2) + SampleSet(n - 1, 2) + SampleSet(n, 2) + SampleSet(n + 1, 2) + SampleSet(n + 2, 2) + SampleSet(n + 3, 2)) / 7
        'Next

        ' nine-point centered average
        'For n = 4 To SampleSet.GetUpperBound(0) - 4
        'SampleSet(n, 3) = (SampleSet(n - 4, 2) + SampleSet(n - 3, 2) + SampleSet(n - 2, 2) + SampleSet(n - 1, 2) + SampleSet(n, 2) + SampleSet(n + 1, 2) + SampleSet(n + 2, 2) + SampleSet(n + 3, 2) + SampleSet(n + 4, 2)) / 9
        'Next

        Dim ScanPoint, PeakPoint, Rmax, Rpoint, PriorRpoint, InterbeatSamples As Integer, PeakMax As Double

        ' we begin by finding the first R-wave in the trace
        ScanPoint = 0
        PeakMax = Double.MinValue
        For n = ScanPoint To ScanPoint + LOOKAHEAD_SAMPLES - 1
            If (SampleSet(n, 3) > PeakMax) Then
                PeakMax = SampleSet(n, 3)
                PeakPoint = n
            End If
        Next

        PriorRpoint = 0 ' show that we don't yet have a previous Rmax

        ' we scan forward searching for the first ROI value that's at least 70% of the prior peak
        Do
            PeakMax = PeakMax * 0.7
            PeakPoint = 0

PeakSearch: For n = ScanPoint To ScanPoint + LOOKAHEAD_SAMPLES - 1
                If (SampleSet(n, 3) > PeakMax) Then
                    PeakMax = SampleSet(n, 3)
                    PeakPoint = n
                ElseIf (PeakPoint) Then
                    Exit For
                End If
            Next

            ' if we did not find a local qualifting peak point we scale down our search and retry
            If (PeakPoint = 0) Then
                PeakMax = PeakMax * 0.95
                GoTo PeakSearch
            End If

            ' now we locate the maximum Delta-coded R-wave within 2 samples either side of the ROI peak
            Rmax = 0
            For n = PeakPoint - 2 To PeakPoint + 2
                If SampleSet(n, 2) > Rmax Then
                    Rmax = SampleSet(n, 2)
                    Rpoint = n
                End If
            Next


            If PriorRpoint Then
                InterbeatSamples = Rpoint - PriorRpoint
                SampleSet(Rpoint, 4) = InterbeatSamples
            End If

            PriorRpoint = Rpoint

            ' bump the scanner forward 20 samples past this R-wave
            ScanPoint = Rpoint + 20
        Loop While (ScanPoint + LOOKAHEAD_SAMPLES < LAST_SAMPLE)

    End Sub
    Sub RemoveEctopicBeats(ByRef SampleSet As Array)
        ' This removes ectopic beats from the R-R interval array. It takes Array #4, as runs of interbeat intervals
        ' It takes four interbeat intervals 

        Dim Scanner, PreviousRun, Anchor1, Anchor2, Anchor3, ThisRun, Delta1, Delta2, Delta3 As Integer

        ' zero our #3 Results Array
        For n = 0 To LAST_SAMPLE
            SampleSet(n, 3) = 0
        Next

        ' find the start of the IBI data (scan from '0' to the first non)
ReDo:   Scanner = 0
        Do Until SampleSet(Scanner, 4) <> 0
            Scanner = Scanner + 1
        Loop

        'Console.WriteLine("First non-zero sample found at: " & Scanner)

        PreviousRun = 0

NextRun:

        Anchor1 = Anchor2
        Anchor2 = Anchor3
        Anchor3 = Scanner                    ' drop an anchor at the start of the run

        'Console.WriteLine("Dropping Anchor at: " & Anchor & " with value: " & AnchorVal)
        Do
            Scanner = Scanner + 1
        Loop Until (SampleSet(Scanner, 4)) Or (Scanner >= LAST_SAMPLE)

        ThisRun = Scanner - Anchor3

        If PreviousRun Then

            Delta1 = Delta2                 ' oldest delta
            Delta2 = Delta3
            Delta3 = ThisRun - PreviousRun  ' newest delta

            ' check for a posible PVC pattern in interbeat differences
            If Delta1 < 0 And Delta2 > 0 And Delta3 < 0 Then

                'Console.WriteLine("")
                'Console.WriteLine("Low/High/Low pattern found")
                'Console.WriteLine("   Synth: " & Math.Abs(Delta2 + Delta1 + Delta3) & ", vs: " & Delta2 * 0.1)

                If Math.Abs(Delta2 + Delta1 + Delta3) < (Delta2 * 0.1) Then
                    'Console.WriteLine("PVC Detected!")
                    'Console.WriteLine("   " & Math.Abs(Delta2 + Delta1 + Delta3) & " vs " & Delta2 * 0.1)
                    'Console.WriteLine("    sD1: " & Delta1 & ", D2: " & Delta2 & ", D3: " & Delta3)

                    'SampleSet(Anchor1, 3) = 825 ' show the decision points
                    'SampleSet(Anchor2, 3) = 825
                    'SampleSet(Anchor3, 3) = 825

                    SampleSet(Anchor2, 4) = 0
                    Anchor2 = Int((Anchor1 + Anchor3) / 2)
                    SampleSet(Anchor2, 4) = (Anchor2 - Anchor1)
                    SampleSet(Anchor3, 4) = (Anchor3 - Anchor2)

                    GoTo ReDo
                End If

                'Console.WriteLine("ThisRun: " & ThisRun & ", PreviousRun: " & PreviousRun & ", Delta: " & ThisRun - PreviousRun)
                'Console.WriteLine("Delta: " & ThisRun - PreviousRun)

            End If

        End If

        PreviousRun = ThisRun

        If (Scanner < LAST_SAMPLE) Then GoTo NextRun

    End Sub
    Function GetRwaveCount(ByRef SampleSet As Array) As Integer

        ' Input #4: R-wave events where value is non-zero. Has distance from previous R-wave event

        Dim ScanPoint As Integer, RwaveCount As Integer = 0

        ' scan the entire sample field locating and counting Rwave events

        For ScanPoint = 0 To LAST_SAMPLE
            If SampleSet(ScanPoint, 4) Then RwaveCount = RwaveCount + 1
        Next

        Return RwaveCount

    End Function
    Sub BuildRwaveArrays(ByRef SampleSet As Array)

        RwaveNumber = 0

        For ScanPoint = 0 To LAST_SAMPLE

            If SampleSet(ScanPoint, 4) Then
                RwaveTime(RwaveNumber) = ScanPoint
                RwaveVal(RwaveNumber) = SampleSet(ScanPoint, 4)
                RwaveNumber = RwaveNumber + 1
            End If

        Next
        RwaveNumber = RwaveNumber - 1

    End Sub
    Sub WriteRtoRintervalFile(ByVal SourceFile As String, ByVal RwaveCount As Integer)

        Dim RRintervalFile = Replace(SourceFile, ".txt", "-rr.dat")

        Dim file = My.Computer.FileSystem.OpenTextFileWriter(RRintervalFile, False, System.Text.Encoding.ASCII)
        For n = 0 To RwaveNumber
            file.WriteLine(RwaveVal(n) * 3.9)
        Next
        file.Close()

    End Sub
    Sub WriteHeartWaveFile(ByVal SourceFile As String, ByVal RwaveCount As Integer)

        Dim RRintervalFile = Replace(SourceFile, ".txt", "-wave.dat")
        Dim file = My.Computer.FileSystem.OpenTextFileWriter(RRintervalFile, False, System.Text.Encoding.ASCII)
        For n = 0 To RwaveNumber
            Dim val = RwaveVal(n)
            For i = 0 To val
                file.WriteLine(val)
            Next
        Next
        file.Close()

    End Sub
    Sub BuildRmsTimeline()

        'Buterworth Low-Pass 100hz/ 5hz:  GAIN:  7.313751515 / yv0: 0.726542528
        '                         / 1hz:        32.82051595  /      0.9390625058
        '                          10hz:         4.077683537 /      0.5095254495
        '                           3hz:        11.57889499  /      0.8272719460
        '                           4hz:         8.915815088 /      0.7756795110
        '                         0.5hz:        64.65674116  /      0.9690674172
        '                         0.1hz:       319.308839    /      0.9937364715
        Dim xv0, xv1, yv0, yv1, Sum As Double, polarity As Boolean

        For n = 0 To RwaveNumber
            RmsVal(n) = 0
        Next

        xv1 = RwaveVal(0)
        RmsMax = Double.MinValue

        For n = 1 To RwaveNumber
            xv0 = xv1
            xv1 = RwaveVal(n) / 64.65674116
            yv0 = yv1
            yv1 = (xv0 + xv1) + (0.9690674172 * yv0)

            'Console.WriteLine("In: " & RwaveVal(n) & ", Out: " & yv1)

            If (polarity Xor (RwaveVal(n) > yv1)) Then
                RmsVal(n) = Sum
                If Sum > RmsMax Then
                    RmsMax = Sum
                End If
                polarity = (RwaveVal(n) > yv1)
                Sum = 0
            End If
            Sum = Sum + (Math.Abs(RwaveVal(n) - yv1) * (RwaveTime(n) - RwaveTime(n - 1)))

        Next
        RmsVal(RwaveNumber) = Sum

        ' now we rescale the RmsVal array to 2*YSCALE
        Dim RmsScale = 2 * YSCALE / RmsMax
        For n = 0 To RwaveNumber
            RmsVal(n) = RmsVal(n) * RmsScale - YSCALE
        Next

    End Sub
    Sub AverageAndInvertRwave()

        Dim SkipCount As Integer = Int(RwaveCount * 0.05)
        Dim Sum As Integer = 0

        For i = SkipCount To RwaveCount - SkipCount
            Sum = Sum + RwaveVal(i)
        Next
        Sum = Sum / (RwaveCount - 2 * SkipCount)

        For i = 0 To RwaveCount - 1
            RwaveVal(i) = Sum - RwaveVal(i)
        Next

    End Sub
    Sub RebaseAndInvertRwaves()
		' This brings the r-wave intervals to a flat baseline. Lowess smoothing
		' is used to create a phase-neutral tracking curve from which individual
		' r-wave intervals are subtracted.

        Lowess2(RwaveTime, RwaveVal, RwaveVals, 31)

        For i = 0 To RwaveCount - 1
			RwaveVal(i) = RwaveVals(i) - RwaveVal(i)
		Next

	End Sub
	Sub FindHrvPeaks()
		' This scans the <RwaveTime|Rwave Val> array pair to alternatively
		' locate the maximum and minimum heart rate value. When found, the
		' <Time|Val> are placed into the <PeakTimes|PeakVals> array pair.

		Dim LocalMax, CurrentVal As Double
		Dim PeakIndex As Integer, CurrentIndex As Integer = 0
		Dim PeakTimes, PeakVals As New Collection

		' search for positive maximum before next zero-crossing
PosPeak: LocalMax = Double.MinValue
		Do
			CurrentVal = RwaveVal(CurrentIndex)
			If CurrentVal > LocalMax Then
				LocalMax = CurrentVal
				PeakIndex = RwaveTime(CurrentIndex)
			End If
			CurrentIndex = CurrentIndex + 1
			If CurrentIndex > (RwaveCount - 1) Then GoTo BuildArrays
		Loop Until CurrentVal < 0

		PeakTimes.Add(PeakIndex)
		PeakVals.Add(LocalMax)

		' search for negative maximum before next zero-crossing
NegPeak: LocalMax = Double.MaxValue
		Do
			CurrentVal = RwaveVal(CurrentIndex)
			If CurrentVal < LocalMax Then
				LocalMax = CurrentVal
				PeakIndex = RwaveTime(CurrentIndex)
			End If
			CurrentIndex = CurrentIndex + 1
			If CurrentIndex > (RwaveCount - 1) Then GoTo BuildArrays
		Loop Until CurrentVal > 0

		PeakTimes.Add(PeakIndex)
		PeakVals.Add(LocalMax)

		GoTo PosPeak

		' having built adhoc collections of the times & vals, we
		' get the count, resize the permanent arrays, enumerate the
		' collections into the arrays, and discard the collections

BuildArrays:

		Array.Resize(PeakTime, PeakTimes.Count)
		Array.Resize(PeakVal, PeakVals.Count)

		Dim TimesEnum As IEnumerator = PeakTimes.GetEnumerator()
		Dim ValsEnum As IEnumerator = PeakVals.GetEnumerator()

		CurrentIndex = 0
		While TimesEnum.MoveNext() And ValsEnum.MoveNext()
			PeakTime(CurrentIndex) = TimesEnum.Current
			PeakVal(CurrentIndex) = ValsEnum.Current
			CurrentIndex = CurrentIndex + 1
		End While
		LastPeak = CurrentIndex - 1

		Console.WriteLine("HRV Peaks Found: " & CurrentIndex)

	End Sub
	Sub MeasurePeakToPeak()

		Dim RmsScale As Double

		Array.Resize(RmsVal, LastPeak)
		Array.Resize(RmsVals, LastPeak)

		RmsMax = Double.MinValue
		RmsMin = Double.MaxValue

		For n = 0 To LastPeak - 1
			RmsVal(n) = Math.Abs(PeakVal(n) - PeakVal(n + 1))
			If RmsVal(n) > RmsMax Then RmsMax = RmsVal(n)
			If RmsVal(n) < RmsMin Then RmsMin = RmsVal(n)
		Next

		' shooth RmsVal[] into RmsVals[]
		' Lowess2(PeakTime, RmsVal, RmsVals, 23)
		Lowess2(PeakTime, RmsVal, RmsVals, 30)

		RmsScale = 2 * YSCALE / (RmsMax - RmsMin)

		' now we find the location of the largest RmsVal[]
		RmsMax = Double.MinValue

		For n = 0 To LastPeak - 1
			RmsVal(n) = (RmsVals(n) - RmsMin) * RmsScale - YSCALE
			If RmsVal(n) > RmsMax Then
				RmsMax = RmsVal(n)
				PeakPoint = PeakTime(n)
			End If
		Next

	End Sub
	Sub RescaleBR(ByRef SampleSet As Array)

		Dim BR_Max = Double.MinValue, BR_Min = Double.MaxValue, BR_Scale As Double

		For n = 256 * 10 To LAST_SAMPLE - 256 * 10
			If SampleSet(n, 1) > BR_Max Then BR_Max = SampleSet(n, 1)
			If SampleSet(n, 1) < BR_Min Then BR_Min = SampleSet(n, 1)
		Next

		If BR_Max < -BR_Min Then BR_Max = -BR_Min

		BR_Scale = YSCALE / BR_Max * 0.98

		For n = 0 To LAST_SAMPLE
			SampleSet(n, 1) = SampleSet(n, 1) * BR_Scale
		Next

	End Sub
	Sub RescaleHR()

		Dim HR_Max = Double.MinValue, HR_Min = Double.MaxValue, HR_Scale As Double

		For n = 0 To RwaveCount - 1
			If RwaveVal(n) > HR_Max Then HR_Max = RwaveVal(n)
			If RwaveVal(n) < HR_Min Then HR_Min = RwaveVal(n)
		Next

		If HR_Max < -HR_Min Then HR_Max = -HR_Min

		HR_Scale = YSCALE / HR_Max * 0.98

		For n = 0 To RwaveCount - 1
			RwaveVal(n) = RwaveVal(n) * HR_Scale
		Next

	End Sub
	Sub ProcessBreathData(ByVal SampleSet)

		'the previous positive going zero crossing event time
		Dim SampleScan, AvgPoint, PreviousAvgPoint, SampleIndex(3), PreviousSampleIndex(3) As Integer

		' clear our results array to receive sparse breathing event data
		For n = 0 To LAST_SAMPLE
			SampleSet(n, 0) = 0
		Next

		SampleScan = 0
		PreviousSampleIndex(0) = 0
		PreviousSampleIndex(1) = 0
		PreviousSampleIndex(2) = 0

		' scan until we're sufficiently negative
GoNeg:  Do
			SampleScan = SampleScan + 1
			If SampleScan > LAST_SAMPLE Then Exit Sub
		Loop Until SampleSet(SampleScan, 1) < (-YSCALE * 0.15)

		' we're well below the zero line... so now we look for three positive going points
		SampleIndex(0) = 0
		SampleIndex(1) = 0
		SampleIndex(2) = 0

		Do
			SampleScan = SampleScan + 1
			If SampleScan > LAST_SAMPLE Then Exit Sub

			If SampleIndex(0) = 0 And SampleSet(SampleScan, 1) > (-YSCALE * 0.1) Then SampleIndex(0) = SampleScan
			If SampleIndex(1) = 0 And SampleSet(SampleScan, 1) > 0 Then SampleIndex(1) = SampleScan
			If SampleIndex(2) = 0 And SampleSet(SampleScan, 1) > (+YSCALE * 0.1) Then SampleIndex(2) = SampleScan

		Loop Until SampleIndex(2)

		' we've JUST crossed above zero. So we're at the end of a respiratory cycle.
		' we calculate the breathing rate and place it at the midpoint.

		AvgPoint = (SampleIndex(0) + SampleIndex(1) + SampleIndex(2)) / 3
		PreviousAvgPoint = (PreviousSampleIndex(0) + PreviousSampleIndex(1) + PreviousSampleIndex(2)) / 3

		SampleSet(Math.Round((AvgPoint + PreviousAvgPoint) / 2), 0) = 60 / ((AvgPoint - PreviousAvgPoint) / SAMPLES_PER_SECOND)

		PreviousSampleIndex(0) = SampleIndex(0)
		PreviousSampleIndex(1) = SampleIndex(1)
		PreviousSampleIndex(2) = SampleIndex(2)

		GoTo GoNeg

	End Sub
	Sub PhaseLockBreathing(ByRef SampleSet As Array)
		'==========================================================================
		' Our goal here is to take noisy breath data and find its actual de-noised
		' breathing rate. We do this by implementing a phase-locked loop to model
		' the client's paced breathing. Even though the client may not be breathing
		' in a uniform manner, we know they are attempting to follow a pacer. And
		' what we really want is to reconstruct instantaneous pacing rate using
		' hints from their actual breathing.
		'--------------------------------------------------------------------------
		Dim INITIAL_BREATHS_PER_MIN = 5.5	' our oscillator's initial frequency
		Dim Pi = System.Math.PI			' get Pi for our use.
		Dim Quadrant2 = 1 * Pi / 2		' get the end of the 1st quadrant
		Dim Quadrant3 = 2 * Pi / 2		' get the end of the 2nd quadrant
		Dim Quadrant4 = 3 * Pi / 2		' get the end of the 3rd quadrant
		Dim CosScale = YSCALE / 2			' scale the cosine to 3/4 of full display scale.
		Dim Omega = 2 * Pi / 60 * INITIAL_BREATHS_PER_MIN / SAMPLES_PER_SECOND
		Dim OmegaAdjust = 1.0005
		Dim Phase = 0.0, OscVal = 0.0

		For n = 0 To LAST_SAMPLE
			Phase = Phase + Omega						' advance our osccillator
			OscVal = CosScale * System.Math.Cos(Phase)	' get the next oscillator value
			SampleSet(n, 2) = OscVal					' plot it so we can see it

			If Phase < Quadrant2 Then
				If SampleSet(n, 1) < OscVal Then
					Omega = Omega * OmegaAdjust
				Else
					Omega = Omega / OmegaAdjust
				End If

			ElseIf Phase < Quadrant3 Then
				If SampleSet(n, 1) < OscVal Then
					Omega = Omega / OmegaAdjust
				Else
					Omega = Omega * OmegaAdjust
				End If

			ElseIf Phase < Quadrant4 Then
				If SampleSet(n, 1) < OscVal Then
					Omega = Omega * OmegaAdjust
				Else
					Omega = Omega / OmegaAdjust
				End If

			Else
				If SampleSet(n, 1) < OscVal Then
					Omega = Omega / OmegaAdjust
				Else
					Omega = Omega * OmegaAdjust
				End If

			End If


			'SampleSet(n, 1) = 0
		Next





	End Sub

	Sub TrackBreathingRate(ByRef SampleSet As Array)
		'==========================================================================
		' Our goal here is to take noisy breath data and find its actual de-noised
		' breathing rate. We do this with a poor-man's curve fit. We determine the
		' distance between successive maxima, minima, positive and negative zero-
		' crossings, placing those into a sparse scatterplot array to which we then
		' apply LOWESS (Locally Weighted Scatterplot Smoothing). This works for us
		' since the successive feature distances SHOULD be uniformly increasing as
		' the subject's breathing is slowed.
		'--------------------------------------------------------------------------
		Dim MinValue, MaxValue, CurrentVal As Double
		Dim MinMaxIndex As Integer, CurrentIndex As Integer = 0
		Dim PrevMaxIndex, PrevMinIndex, PrevPosIndex, PrevNegIndex As Integer
		Dim EventTimes, EventVals As New Collection

		' this captures the local positive 'LocalMinMax' maximum
		' occuring before the next negative-going zero-crossing.

PosPeak: MaxValue = Double.MinValue	' set an initial minimum comparison value
		Do
			CurrentVal = SampleSet(CurrentIndex, 1)
			If CurrentVal > MaxValue Then
				MaxValue = CurrentVal
				MinMaxIndex = CurrentIndex
			End If
			CurrentIndex = CurrentIndex + 1
			If CurrentIndex > LAST_SAMPLE Then GoTo BuildArrays
		Loop Until CurrentVal < 0

		' we have just dropped below the zero point, so we have found both
		' the next negative-going 0-crossing =and= the next local maximum'
		' peak. So we record these two events into the event collections.

		' record the inter peak event
		EventTimes.Add((MinMaxIndex + PrevMaxIndex) / 2) ' add it at the centerpoint between the events
		EventVals.Add(MinMaxIndex - PrevMaxIndex)		 ' add the interval between the events

		' record the inter 0-crossing event
		'EventTimes.Add((CurrentIndex + PrevNegIndex) / 2) ' add it at the centerpoint between the events
		'EventVals.Add(CurrentIndex - PrevNegIndex)		  ' add the interval between the events

		PrevMaxIndex = MinMaxIndex	' update previous event indexes with
		PrevNegIndex = CurrentIndex	' the current indexes for next time

		' search for negative maximum before next zero-crossing

NegPeak: MinValue = Double.MaxValue	' set an initial maximum comparison value
		Do
			CurrentVal = SampleSet(CurrentIndex, 1)
			If CurrentVal < MinValue Then
				MinValue = CurrentVal
				MinMaxIndex = CurrentIndex
			End If
			CurrentIndex = CurrentIndex + 1
			If CurrentIndex > LAST_SAMPLE Then GoTo BuildArrays
		Loop Until CurrentVal > 0

		' we have just moved above the zero point, so we have found both
		' the next positive-going 0-crossing =and= the next local mimumum
		' peak. So we record these two events into the event collections.

		' record the inter peak event
		EventTimes.Add((MinMaxIndex + PrevMinIndex) / 2) ' add it at the centerpoint between the events
		EventVals.Add(MinMaxIndex - PrevMinIndex)		 ' add the interval between the events

		' record the inter 0-crossing event
		'EventTimes.Add((CurrentIndex + PrevPosIndex) / 2) ' add it at the centerpoint between the events
		'EventVals.Add(CurrentIndex - PrevPosIndex)		  ' add the interval between the events

		PrevMinIndex = MinMaxIndex	' update previous event indexes with
		PrevPosIndex = CurrentIndex	' the current indexes for next time

		GoTo PosPeak

		' having built adhoc collections of the times & vals for FOUR events,
		' we get their count, resize the permanent arrays, and enumerate the
		' collections into permanent arrays. The collections are local and
		' will be disarded upon our exit

BuildArrays:

		Array.Resize(BreathEventTime, EventTimes.Count)
		Array.Resize(BreathEventVal, EventVals.Count)
		Array.Resize(BreathEventPeriods, EventVals.Count)

		Dim TimesEnum As IEnumerator = EventTimes.GetEnumerator()
		Dim ValsEnum As IEnumerator = EventVals.GetEnumerator()

		' we discard the first eight events since we saved on startup initialization

		For n = 0 To 7
			TimesEnum.MoveNext()
			ValsEnum.MoveNext()
		Next

		Console.WriteLine("Converting Collections into Arrays")

		CurrentIndex = 0
		While TimesEnum.MoveNext() And ValsEnum.MoveNext()
			BreathEventTime(CurrentIndex) = TimesEnum.Current
			BreathEventVal(CurrentIndex) = ValsEnum.Current
			CurrentIndex = CurrentIndex + 1
		End While
		LastBreathEvent = CurrentIndex - 1	' capture the index of the final breath event

		Console.WriteLine("Lowess Smoothing the Arrays")

		Lowess2(BreathEventTime, BreathEventVal, BreathEventPeriods, 12)

		Console.WriteLine("Rescaling the Breath Events for visualization")

		MaxValue = Double.MinValue	' set an initial minimum comparison value
		MinValue = Double.MaxValue	' set an initial minimum comparison value
		Dim Breath_Scale As Double

		'----------------------------------------------------------------------------------------
		For n = 0 To LastBreathEvent
			If BreathEventPeriods(n) < MinValue Then MinValue = BreathEventPeriods(n)
			If BreathEventPeriods(n) > MaxValue Then MaxValue = BreathEventPeriods(n)
		Next

		Breath_Scale = (2 * YSCALE) / (MaxValue - MinValue) * 0.98

		For n = 0 To LastBreathEvent
			'BreathEventPeriods(n) = (BreathEventPeriods(n) - MinValue) * Breath_Scale - YSCALE
			BreathEventPeriods(n) = (MaxValue - BreathEventPeriods(n)) * Breath_Scale - YSCALE
		Next
		'----------------------------------------------------------------------------------------

	End Sub

End Module