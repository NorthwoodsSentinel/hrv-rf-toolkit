﻿Public Module Constants

    Public Const TRACE_WIDTH = 3        ' width of the system's traces
    Public Const THICK_TRACE = 5        ' width of the system's traces
    Public Const TRACE_COUNT = 6        ' vertical dimension of the data array

    Public Const SAMPLES_PER_SECOND = 256
    Public Const LOOKAHEAD_SECONDS = 2
    Public Const LOOKAHEAD_SAMPLES = LOOKAHEAD_SECONDS * SAMPLES_PER_SECOND

    Public Const YSCALE = 150
    Public Const HRV_SPAN = SAMPLES_PER_SECOND * 4

	Public LAST_SAMPLE = 50000

    Public SampleCount, RwaveCount, RmsCount, RwaveNumber, RmsIndex As Integer

    Public RwaveTime(1), RwaveVal(1), RwaveVals(1) As Double
    Public RmsTime(1), RmsVal(1), RmsVals(1), RmsMax, RmsMin As Double
    Public RmsPower As Array

    Public PeakTime(1), LastPeak As Integer
    Public PeakVal(1) As Double
	Public PeakPoint As Integer

	Public BreathEventTime(1) As Integer	' location of midpoint between successive breath events
	Public BreathEventVal(1) As Integer		' value of the sample distance between successive breath events
	Public BreathEventPeriods(1) As Integer	' lowess-smoothed distances between successive breath events
	Public LastBreathEvent As Integer		' the index of the last Breath event

    Public FileProcessed = False

End Module

